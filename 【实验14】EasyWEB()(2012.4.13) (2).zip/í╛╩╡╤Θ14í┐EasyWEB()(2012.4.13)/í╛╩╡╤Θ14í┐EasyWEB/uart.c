#include <stdint.h>
#include <stdio.h>
#include "stdarg.h"

static uint8_t gBuffer[512];
void uartPrint(const  char *format, ...)
{
	va_list  vArgs;
	uint8_t i = 0;

	va_start(vArgs, format);
    vsprintf((char *)gBuffer, (char const *)format, vArgs);
    va_end(vArgs);

	while (gBuffer[i] != 0)
	{
		UART0_sendChar(gBuffer[i]);
		i++;
	}

//	UART0_snd(gBuffer, i);
}